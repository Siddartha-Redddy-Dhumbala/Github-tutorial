package hassets;

public class hasset1 {

}
