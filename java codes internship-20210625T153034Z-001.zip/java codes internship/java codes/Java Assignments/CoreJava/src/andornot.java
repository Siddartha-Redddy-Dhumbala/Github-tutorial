
public class andornot {
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		System.out.println(i > j && j > i);
		System.out.println(j > i & j < i);
		System.out.println(j > i || i > j);

	}
}
