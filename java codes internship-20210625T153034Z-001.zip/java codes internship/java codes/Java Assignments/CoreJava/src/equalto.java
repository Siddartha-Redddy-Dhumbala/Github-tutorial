
public class equalto {
	public static void main(String[] args) {
		char A = 'a';
		char B = 'a';
		System.out.println(A == B);

		String s1 = new String("BHANU");
		String s2 = new String("TEJA");
		System.out.println(s1 != s2);

	}

}
