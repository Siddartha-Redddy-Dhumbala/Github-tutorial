
public class StaticinInstance {
	static void staticMethod() {

	}

}
