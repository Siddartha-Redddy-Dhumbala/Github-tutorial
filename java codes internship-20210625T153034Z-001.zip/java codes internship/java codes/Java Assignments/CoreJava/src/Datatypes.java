
public class Datatypes {
	public static void main(String[] args) {
		int i = 10;
		System.out.println("Integer is " + i);

		boolean bhanu = true;
		if (bhanu == true)
			System.out.println("Bhanu Teja");

		char char1 = 'b';
		char char2 = 'B';
		System.out.println("char1= " + char1);
		System.out.println("char2= " + char2);

		float num = 1.1f;
		System.out.println("float= " + num);

		double num1 = 100.2;
		System.out.println("double= " + num1);

	}

}
