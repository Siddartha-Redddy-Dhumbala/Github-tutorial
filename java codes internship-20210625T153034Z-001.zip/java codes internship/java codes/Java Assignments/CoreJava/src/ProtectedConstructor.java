
public class ProtectedConstructor {

	protected ProtectedConstructor() {
		System.out.println("Hello Everyone");
	}

	public static void main(String args[]) {
		ProtectedConstructor d1 = new ProtectedConstructor();
	}
}
