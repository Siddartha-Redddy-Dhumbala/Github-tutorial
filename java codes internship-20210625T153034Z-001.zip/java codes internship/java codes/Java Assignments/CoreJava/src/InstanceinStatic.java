
public class InstanceinStatic {
   

}
