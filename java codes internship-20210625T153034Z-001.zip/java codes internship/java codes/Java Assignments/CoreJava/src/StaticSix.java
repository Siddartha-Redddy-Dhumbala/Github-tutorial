
public class StaticSix {
static int a = 20;
public static void main(String[] args) {
	
	System.out.println(StaticSix.a);
}
}
