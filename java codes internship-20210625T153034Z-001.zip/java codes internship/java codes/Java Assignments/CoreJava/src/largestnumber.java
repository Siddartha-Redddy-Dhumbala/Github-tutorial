
public class largestnumber {
	public static void main(String[] args) {
		int a = 1;
		int b = 2;
		int c = 3;
		if (a >= b && a >= c)
			System.out.println("Largest number is " + a);
		else if (c >= a && c >= b)
			System.out.println("Largest number is " + c);

	}

}
