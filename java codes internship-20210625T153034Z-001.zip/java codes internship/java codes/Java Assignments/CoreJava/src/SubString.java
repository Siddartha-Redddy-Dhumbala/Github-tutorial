
public class SubString {
	public static void main(String args[]) {

		String Str = new String("My Name is Bhanu Teja");

		System.out.print("The extracted substring is : ");
		System.out.println(Str.substring(10));
	}
}
