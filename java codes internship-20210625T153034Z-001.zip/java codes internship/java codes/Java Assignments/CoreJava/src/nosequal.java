
public class nosequal {
	public static void main(String[] args) {
		int a = 777;
		int b = 999;
		System.out.println(a == b);
		
		int c = 99;
		int d = 99;
		System.out.println(c == d);
	}

}
