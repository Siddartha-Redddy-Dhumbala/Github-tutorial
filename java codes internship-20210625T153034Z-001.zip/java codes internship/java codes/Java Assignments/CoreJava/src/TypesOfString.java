
public class TypesOfString {
	public static void main(String[] args) {

		String s = "Bhanu";// String Literal
		String s1 = new String("Teja");// new keyword
		char c[] = { 'j', 'a', 'v', 'a' };// character array
		System.out.println(s);
		System.out.println(s1);
		System.out.println(c);

	}
}
