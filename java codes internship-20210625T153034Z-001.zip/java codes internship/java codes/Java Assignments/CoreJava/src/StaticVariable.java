
public class StaticVariable {
	static int number = 20;

	public void main(String[] args) {
		StaticVariable n = new StaticVariable();
		System.out.println(n.number);
	}
}
