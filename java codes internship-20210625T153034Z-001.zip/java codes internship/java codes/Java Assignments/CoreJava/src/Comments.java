
public class Comments {
	public static void main(String[] args) {
		int i = 10; // i is first variable
		System.out.println("first variable is " + i);
		int j = 20; /*
					 * j is second a variable
					 */
		System.out.println("second variable is " + j);
		int k = 30;
		/** int k is the thrid variable */
		System.out.println("third variable is " + k);

	}
}
