package hassets;

public class hasset2 {

}
