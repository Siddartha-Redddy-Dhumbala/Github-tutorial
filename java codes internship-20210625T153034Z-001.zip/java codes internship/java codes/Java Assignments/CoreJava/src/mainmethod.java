
public class mainmethod {
	static void m1() {
		System.out.println("Bhanu");
	}

	public static void main(String[] args) {
		m1(); // calling m1 in main method
	}
}
