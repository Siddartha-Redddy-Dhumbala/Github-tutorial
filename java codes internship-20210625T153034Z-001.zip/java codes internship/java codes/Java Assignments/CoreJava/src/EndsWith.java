
public class EndsWith {
	public static void main(String args[]){  
		String s1="Java with Bhanu";  
		System.out.println(s1.endsWith("u"));  
		System.out.println(s1.endsWith("Bhanu"));  
		}
}
