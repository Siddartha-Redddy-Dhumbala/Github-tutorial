
public class incdecoperators {
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		System.out.println("i++ is equal to " + (i++));
		System.out.println("j-- is equal to " + (j--));
		System.out.println("++i is equal to " + (++i));
		System.out.println("--j is equal to " + (--j));
	}

}
