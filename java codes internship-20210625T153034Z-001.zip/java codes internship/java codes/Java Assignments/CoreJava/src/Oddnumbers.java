
public class Oddnumbers {
	public static void main(String[] args) {
		int j = 100;
		System.out.println("The odd numbers from 1 to "+j+"are: ");
		for(int i = 1; i<=j; i++) {
			if(i % 2 != 0) {
				System.out.println(i + " ");
			}
		}
		
		
		
		
	}

}
