
public class ConstructorMultiple {
	

	ConstructorMultiple(int i)
	    {
	        System.out.println(i);
	    }

	    public static void main(String args[])
	    {
	    	ConstructorMultiple b = new ConstructorMultiple();
	        int x = 10;
	        while( x > 0)
	        {
	           
	        }
	    }
	}

