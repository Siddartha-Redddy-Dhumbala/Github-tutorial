
public class NumberFormatException {

	public static void main(String[] args) {
		int x = Integer.parseInt("30k");
		System.out.println(x);
	}
}
