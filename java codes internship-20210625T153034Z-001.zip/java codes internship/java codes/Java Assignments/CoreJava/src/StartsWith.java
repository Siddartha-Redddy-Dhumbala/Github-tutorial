
public class StartsWith {
	public static void main(String args[]) {
		String s1 = "Bhanu Teja is my Name";
		System.out.println(s1.startsWith("Bh"));
		System.out.println(s1.startsWith("Bhanu"));
	}
}
