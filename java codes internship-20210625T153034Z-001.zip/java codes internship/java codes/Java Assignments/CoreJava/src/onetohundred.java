
public class onetohundred {
public static void main(String[] args) {
	int limit = 100;
	int num = 8;
	System.out.println("The Output is: ");
	while(limit>= num) {
		num++;
		if(num%2==0) {
			System.out.println(num+" ");
		}
	}
}
}
