
public class ReplaceString {
	public static void main(String args[]) {

		String Str = new String("My name is Bhanu Teja");

		System.out.print("After replacing all a with T : ");
		System.out.println(Str.replace('a', 'T'));

		System.out.print("After replacing all e with D : ");
		System.out.println(Str.replace('e', 'D'));

	}
}
