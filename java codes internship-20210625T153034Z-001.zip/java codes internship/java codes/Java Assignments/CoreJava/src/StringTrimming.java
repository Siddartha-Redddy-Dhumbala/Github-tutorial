
public class StringTrimming {
	public static void main(String args[]) {

		String s = " Bhanu Teja is working on Java  ";
		System.out.println(s.trim());

		s = " Bhanu loves Driving";
		System.out.println(s.trim());

	}
}
