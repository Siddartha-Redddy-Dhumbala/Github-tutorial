
public class StringCase {
	public static void main(String[] args) {

		String txt = "Bhanu Teja";
		System.out.println(txt.toUpperCase());
		System.out.println(txt.toLowerCase());
	}

}
