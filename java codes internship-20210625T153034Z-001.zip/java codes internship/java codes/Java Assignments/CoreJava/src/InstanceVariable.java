
public class InstanceVariable {
	int instance = 20;

	public static void main(String[] args) {
		InstanceVariable number = new InstanceVariable();
		System.out.println(number.instance);
	}

}
